The attach point of the final antenna box and the tip of the antenna is through the center
of the final box. The reason for this is because there was a question about this on Piazza
but no one answered it, so I assumed this. If this was not part of the specifications then
all we would have to do is translate the antenna tip (the sphere) by the length of half the
side of the box along its z-axis.